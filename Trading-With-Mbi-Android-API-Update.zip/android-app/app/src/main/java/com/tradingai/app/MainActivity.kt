package com.tradingai.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TradingDashboard() }
    }
}

private data class AnalysisView(
    val status: String,
    val signal: String,
    val reason: String,
    val price: String,
    val trend: String,
    val cloud: String,
    val chikou: String,
    val rsi: String,
    val atr: String,
    val supports: String,
    val resistances: String,
    val pullback: String
)

private object TradingApi {
    private val executor = Executors.newSingleThreadExecutor()

    fun analyze(
        baseUrl: String,
        symbol: String,
        timeframe: String,
        onResult: (Result<AnalysisView>) -> Unit
    ) {
        executor.execute {
            try {
                val root = baseUrl.trim().trimEnd('/')
                require(root.startsWith("https://")) {
                    "آدرس API باید با https:// شروع شود."
                }

                val interval = when (timeframe) {
                    "M1" -> "1m"
                    "M5" -> "5m"
                    "M15" -> "15m"
                    "M30" -> "30m"
                    "H1" -> "1h"
                    "H4" -> "4h"
                    "D1" -> "1d"
                    else -> throw IllegalArgumentException("تایم‌فریم پشتیبانی نمی‌شود.")
                }

                val encodedSymbol = URLEncoder.encode(symbol, "UTF-8")
                val candleResponse = request(
                    "$root/api/v1/market/$encodedSymbol/ohlc?interval=$interval&limit=150",
                    "GET"
                )
                val bars = candleResponse.optJSONArray("bars")
                    ?: throw IllegalStateException("داده کندل در پاسخ سرور وجود ندارد.")

                val closedCandles = JSONArray()
                for (i in 0 until bars.length()) {
                    val bar = bars.optJSONObject(i) ?: continue
                    if (bar.optBoolean("isOpen", false)) continue
                    val candle = JSONObject()
                        .put("open", bar.getDouble("open"))
                        .put("high", bar.getDouble("high"))
                        .put("low", bar.getDouble("low"))
                        .put("close", bar.getDouble("close"))
                    if (bar.has("timestamp")) candle.put("timestamp", bar.get("timestamp"))
                    closedCandles.put(candle)
                }

                if (closedCandles.length() < 78) {
                    throw IllegalStateException(
                        "تعداد کندل‌های بسته کافی نیست: ${closedCandles.length()} از حداقل 78."
                    )
                }

                val payload = JSONObject()
                    .put("symbol", symbol)
                    .put("timeframe", timeframe)
                    .put("candles", closedCandles)

                val analysis = request(
                    "$root/api/v1/analysis",
                    "POST",
                    payload.toString()
                )

                val indicators = analysis.optJSONObject("indicators") ?: JSONObject()
                val ichimoku = indicators.optJSONObject("ichimoku") ?: JSONObject()
                val rsi = indicators.optJSONObject("rsi") ?: JSONObject()
                val atr = indicators.optJSONObject("atr") ?: JSONObject()
                val sr = analysis.optJSONObject("support_resistance") ?: JSONObject()
                val pullback = analysis.optJSONObject("pullback") ?: JSONObject()
                val zone = pullback.optJSONObject("zone")

                val result = AnalysisView(
                    status = analysis.optString("signal_status", analysis.optString("status", "UNKNOWN")),
                    signal = analysis.optString("signal", "NO TRADE"),
                    reason = analysis.optString("signal_reason", "دلیل سیگنال از سرور دریافت نشد."),
                    price = analysis.opt("entry_price")?.toString() ?: "—",
                    trend = analysis.optString("trend", "—"),
                    cloud = ichimoku.optString("price_vs_cloud", "UNAVAILABLE"),
                    chikou = ichimoku.optString("chikou_position", "UNAVAILABLE"),
                    rsi = rsi.opt("value")?.toString() ?: "—",
                    atr = atr.opt("value")?.toString() ?: "—",
                    supports = formatLevels(sr.optJSONArray("supports")),
                    resistances = formatLevels(sr.optJSONArray("resistances")),
                    pullback = if (zone != null) {
                        "${zone.opt("lower")} تا ${zone.opt("upper")} (${pullback.optString("direction")})"
                    } else {
                        pullback.optString("status", "در دسترس نیست")
                    }
                )
                onResult(Result.success(result))
            } catch (error: Exception) {
                onResult(Result.failure(error))
            }
        }
    }

    private fun formatLevels(levels: JSONArray?): String {
        if (levels == null || levels.length() == 0) return "سطح تأییدشده‌ای یافت نشد"
        return (0 until levels.length()).mapNotNull { index ->
            levels.optJSONObject(index)?.let { level ->
                "${level.opt("price")} (${level.optString("strength")})"
            }
        }.joinToString("، ")
    }

    private fun request(path: String, method: String, body: String? = null): JSONObject {
        val connection = URL(path).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 15000
            connection.readTimeout = 20000
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = try { JSONObject(text).optString("detail", text) } catch (_: Exception) { text }
                throw IllegalStateException("خطای سرور ($code): $detail")
            }
            return JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradingDashboard() {
    val context = LocalContext.current
    val preferences = remember {
        context.getSharedPreferences("trading_api", Context.MODE_PRIVATE)
    }
    var apiUrl by remember { mutableStateOf(preferences.getString("base_url", "") ?: "") }
    var symbol by remember { mutableStateOf("XAUUSD") }
    var timeframe by remember { mutableStateOf("M5") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("برای دریافت تحلیل، ابتدا آدرس سرور API را وارد کنید.") }
    var analysis by remember { mutableStateOf<AnalysisView?>(null) }

    MaterialTheme {
        Scaffold { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.mipmap.ic_launcher),
                        contentDescription = "fxizadi logo",
                        modifier = Modifier.size(60.dp)
                    )
                    Column {
                        Text("fxizadi", style = MaterialTheme.typography.headlineMedium)
                        Text("SMART MARKET ANALYSIS")
                    }
                }

                OutlinedTextField(
                    value = apiUrl,
                    onValueChange = { apiUrl = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("آدرس سرور API") },
                    placeholder = { Text("https://your-service.onrender.com") },
                    singleLine = true
                )
                Text(
                    "آدرس سرور پس از استقرار در Render وارد می‌شود.",
                    style = MaterialTheme.typography.bodySmall
                )

                Text("نماد معاملاتی", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("XAUUSD", "EURUSD").forEach {
                        FilterChip(
                            selected = symbol == it,
                            onClick = { symbol = it },
                            label = { Text(it) }
                        )
                    }
                }

                Text("تایم‌فریم", style = MaterialTheme.typography.titleMedium)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(listOf("M1", "M5", "M15", "M30"), listOf("H1", "H4", "D1")).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach {
                                FilterChip(
                                    selected = timeframe == it,
                                    onClick = { timeframe = it },
                                    label = { Text(it) }
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        if (apiUrl.isBlank()) {
                            message = "ابتدا آدرس API را وارد کنید. سرور هنوز مستقر نشده است."
                        } else {
                            preferences.edit().putString("base_url", apiUrl.trim()).apply()
                            loading = true
                            message = "در حال دریافت کندل‌های بسته و تحلیل بازار..."
                            analysis = null
                            TradingApi.analyze(apiUrl, symbol, timeframe) { result ->
                                (context as? ComponentActivity)?.runOnUiThread {
                                    loading = false
                                    result.onSuccess {
                                        analysis = it
                                        message = "تحلیل با موفقیت از سرور دریافت شد."
                                    }.onFailure {
                                        message = it.message ?: "خطای نامشخص"
                                    }
                                }
                            }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(if (loading) "در حال تحلیل..." else "دریافت تحلیل بازار")
                }

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("وضعیت اتصال", style = MaterialTheme.typography.titleMedium)
                        Text(message)
                    }
                }

                analysis?.let { result ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("سیگنال $symbol • $timeframe", style = MaterialTheme.typography.titleMedium)
                            Text(result.signal, style = MaterialTheme.typography.headlineMedium)
                            Text(result.reason)
                            HorizontalDivider()
                            InfoLine("قیمت مبنا", result.price)
                            InfoLine("روند", result.trend)
                            InfoLine("موقعیت قیمت نسبت به ابر", result.cloud)
                            InfoLine("موقعیت چیکو", result.chikou)
                            InfoLine("RSI", result.rsi)
                            InfoLine("ATR", result.atr)
                        }
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("حمایت و مقاومت", style = MaterialTheme.typography.titleMedium)
                            InfoLine("حمایت‌ها", result.supports)
                            InfoLine("مقاومت‌ها", result.resistances)
                            HorizontalDivider()
                            Text("محدوده اصلاح", style = MaterialTheme.typography.titleMedium)
                            Text(result.pullback)
                        }
                    }
                }

                Text(
                    "این برنامه ابزار تحلیل و ارائه سیگنال است و هیچ سفارش معاملاتی ارسال نمی‌کند.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
