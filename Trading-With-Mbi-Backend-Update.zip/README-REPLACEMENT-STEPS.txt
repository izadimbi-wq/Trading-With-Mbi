Trading-With-Mbi backend update

1) Copy backend/app/technical_analysis/ into backend/app/.
2) Replace backend/app/risk_management/sizing.py, trade_levels.py and trade_plan.py with the included complete files.
3) Replace backend/app/main.py with the included complete API entrypoint.
4) Replace backend/app/tests/test_strategy.py and add test_levels.py and test_trade_plan.py. Keep the existing test_signal_engine.py and Test_trade_levels.py.
5) Replace .github/workflows/backend-tests.yml.
6) Apply LEGACY-CLEANUP.txt only after copying the new canonical package.
7) The new analysis endpoint is POST /api/v1/analysis. Input: symbol, timeframe, closed candles, optional balance, risk_percent (max 1), and contract {tick_size,tick_value_per_lot,min_lot,lot_step,max_lot}. A trade plan is withheld without real broker contract specs. No orders are executed.
8) The Android dashboard currently has no configured deployed API base URL. Do not enter a guessed URL; configure it only after backend deployment. Existing app branding/assets are not changed by this backend package.

Risk policy: 1% maximum account risk; SL=1.5 ATR; TP=2R; lot is rounded down only; if broker minimum lot exceeds budget, the plan is rejected. S/R and pullback are estimates, not reversal guarantees. Confirmation score is not a win probability.
