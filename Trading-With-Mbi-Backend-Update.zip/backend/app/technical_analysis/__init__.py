"""Canonical technical analysis package."""
