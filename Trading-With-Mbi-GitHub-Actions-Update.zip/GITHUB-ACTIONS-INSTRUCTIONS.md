# GitHub Actions APK build update

## Upload these files to the repository

Copy the `.github/workflows/android-apk.yml` file into the repository at exactly:

`.github/workflows/android-apk.yml`

Also apply the Android source patch files from the companion Android update ZIP, preserving their exact repository paths.

## Run the workflow

1. Open the repository on GitHub.
2. Open **Actions**.
3. Select **Build Android APK**.
4. Press **Run workflow** (or push a commit touching `android-app/**`).
5. Wait for the job to finish successfully.
6. Open the completed workflow run and download **Trading-With-Mbi-debug-apk** from **Artifacts**.

## Important

- This workflow expects the Gradle wrapper at `android-app/gradlew`.
- If the wrapper is located elsewhere, update the workflow command to the actual path.
- This workflow builds a debug APK. It does not sign a release APK.
- A successful build does not validate live broker data or authorize live trading.
